package telran.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
@Getter
public class Colors {
    private List<ColorDto> image_colors;


}
