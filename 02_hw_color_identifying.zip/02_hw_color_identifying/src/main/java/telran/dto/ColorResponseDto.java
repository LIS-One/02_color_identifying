package telran.dto;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class ColorResponseDto {
    private ResultDto result;
    private Status status;


}
