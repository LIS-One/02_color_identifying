package telran.dto;

import lombok.Getter;

@Getter
public class ColorDto {
    private String closest_palette_color;
    private String closest_palette_color_parent;
    private double percent;
}
