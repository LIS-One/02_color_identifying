package telran.dto;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class ResultDto {
    private Colors colors;
    }
