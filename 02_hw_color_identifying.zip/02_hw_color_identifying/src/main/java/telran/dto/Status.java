package telran.dto;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class Status {
    private String text;
    private String type;
}
