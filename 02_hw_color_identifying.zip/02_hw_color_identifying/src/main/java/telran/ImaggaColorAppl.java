package telran;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import telran.dto.ColorDto;
import telran.dto.ColorResponseDto;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

public class ImaggaColorAppl {
    public static void main(String[] args) throws URISyntaxException {


        URI uri = UriComponentsBuilder.fromUri(new URI("https://api.imagga.com/v2/colors"))
                .queryParam("image_url", "https://www.pngkey.com/png/detail/105-1051975_tmnt-png-clipart-michelangelo-raphael-teenage-mutant-ninja.png")
                .build(true)
                .toUri();

        RestTemplate restTemplate = new RestTemplate();


        HttpHeaders headers = new HttpHeaders();

        headers.add("Authorization", "Basic YWNjX2M4Yjg1M2Q4NThlOWIxZjphNGZiMzYxNDRmOTkyZWYyMDc2N2Q3NzExNTZhNTE0Yw==");


        RequestEntity<String> request = new RequestEntity<>(headers, HttpMethod.GET, uri);


        ResponseEntity<ColorResponseDto> response = restTemplate.exchange(request, ColorResponseDto.class);
        ColorResponseDto dto = response.getBody();

        if (dto != null && dto.getResult() != null && dto.getResult().getColors() != null) {
            List<ColorDto> imageColors = dto.getResult().getColors().getImage_colors();

            int rows = imageColors.size() + 1;
            int cols = 3;
            String[][] table = new String[rows][cols];


            table[0][0] = "Color Name";
            table[0][1] = "Parent Color Name";
            table[0][2] = "Coverage Percent";


            for (int i = 0; i < imageColors.size(); i++) {
                ColorDto color = imageColors.get(i);
                table[i + 1][0] = color.getClosest_palette_color();
                table[i + 1][1] = color.getClosest_palette_color_parent();
                table[i + 1][2] = String.format("%.2f", color.getPercent());
            }


            for (int i = 0; i < rows; i++) {
                System.out.printf("%-20s %-20s %-20s%n", table[i][0], table[i][1], table[i][2]);
            }
        }


        if (dto != null && dto.getStatus() != null) {
            System.out.println("Status: " + dto.getStatus().getType()
                    + " - " + dto.getStatus().getText());
        }
    }
}
